import{w as o}from"./with-props-DV3pLViQ.js";import{w as e}from"./chunk-K6AXKMTT-O9GPjJZg.js";const i=()=>e("/overview"),n=o(()=>null);export{i as clientLoader,n as default};
