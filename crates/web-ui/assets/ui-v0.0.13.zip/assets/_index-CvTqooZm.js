import{w as o}from"./with-props-DxyFq8RH.js";import{q as e}from"./chunk-7R3XDUXW-BWS8NYh7.js";const i=()=>e("/overview"),n=o(()=>null);export{i as clientLoader,n as default};
