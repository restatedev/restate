import{w as o}from"./with-props-D-mEH-yc.js";import{v as e}from"./chunk-K6AXKMTT-DrcU-HLf.js";const i=()=>e("/overview"),n=o(()=>null);export{i as clientLoader,n as default};
