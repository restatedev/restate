import{w as o}from"./with-props-Dpk9fWn0.js";import{w as e}from"./chunk-K6AXKMTT-BZbsnq7E.js";const i=()=>e("/overview"),n=o(()=>null);export{i as clientLoader,n as default};
