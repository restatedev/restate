import{r as e}from"./responses-BHxycxSx.js";import"./router-ClJJnBTN.js";const t=()=>e("/overview"),i=()=>null;export{t as clientLoader,i as default};
