import{w as o}from"./with-props-CMklFGgo.js";import{w as e}from"./chunk-K6AXKMTT-JCEBrYiK.js";const i=()=>e("/overview"),n=o(()=>null);export{i as clientLoader,n as default};
