import{r as e}from"./responses-XyQyaSrs.js";import"./router-CntpZHug.js";const t=()=>e("/overview"),i=()=>null;export{t as clientLoader,i as default};
