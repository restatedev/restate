const o="invocation";export{o as I};
