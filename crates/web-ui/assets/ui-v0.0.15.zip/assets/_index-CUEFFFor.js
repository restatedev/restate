import{w as o}from"./with-props-Cbo-36nV.js";import{v as e}from"./chunk-K6AXKMTT-CcykLP9N.js";const i=()=>e("/overview"),n=o(()=>null);export{i as clientLoader,n as default};
