import{w as o}from"./with-props-DxyFq8RH.js";import{ao as r}from"./Badge-EQUmNklY.js";import"./index-NOX2FhRB.js";import"./chunk-7R3XDUXW-BWS8NYh7.js";const i=o(r.Component);export{i as default};
