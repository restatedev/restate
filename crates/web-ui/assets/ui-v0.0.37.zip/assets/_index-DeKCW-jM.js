import{w as o}from"./with-props-D5DPvnks.js";import{w as e}from"./chunk-K6AXKMTT-FjLIiUTe.js";const i=()=>e("/overview"),n=o(()=>null);export{i as clientLoader,n as default};
