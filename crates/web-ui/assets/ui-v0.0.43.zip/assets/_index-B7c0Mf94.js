import{w as o}from"./with-props-DpbIHTcx.js";import{w as e}from"./chunk-K6AXKMTT-CdmPzega.js";const i=()=>e("/overview"),n=o(()=>null);export{i as clientLoader,n as default};
